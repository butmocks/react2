import React from 'react';
import { useForm } from 'react-hook-form';

export default function App() {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const onSubmit = data => console.log(data);
  console.log(errors);
  
  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <select {...register("buy_fast_key", { required: true })}>
        <option value="open">open</option>
        <option value=" high"> high</option>
        <option value=" low"> low</option>
        <option value=" close"> close</option>
        <option value=" volume"> volume</option>
      </select>
      <input type="number" placeholder="buy_horizontal_push" {...register("buy_horizontal_push", {required: true, max: 10, min: 0, maxLength: 10, pattern: /7/i})} />
      <select {...register("buy_slow_key", { required: true })}>
        <option value="open">open</option>
        <option value=" high"> high</option>
        <option value=" low"> low</option>
        <option value=" close"> close</option>
        <option value=" volume"> volume</option>
      </select>
      <input type="number" placeholder="buy_vertical_push" {...register("buy_vertical_push", {required: true, max: 3, min: 0, maxLength: 1, pattern: /0.942/i})} />
      <select {...register("sell_fast_key", { required: true })}>
        <option value="open">open</option>
        <option value=" high"> high</option>
        <option value=" low"> low</option>
        <option value=" close"> close</option>
        <option value=" volume"> volume</option>
      </select>
      <input type="number" placeholder="sell_horizontal_push" {...register("sell_horizontal_push", {, max: 10, min: -3, pattern: /10/i})} />
      <select {...register("sell_slow_key")}>
        <option value="open">open</option>
        <option value=" high"> high</option>
        <option value=" low"> low</option>
        <option value=" close"> close</option>
        <option value=" volume"> volume</option>
      </select>
      <input type="number" placeholder="sell_vertical_push" {...register("sell_vertical_push", {required: true, max: 2, min: 0, pattern: /1.184/i})} />
      <input type="number" placeholder="minimal_roi "0"" {...register("minimal_roi "0"", {, pattern: /0.242/i})} />
      <input type="number" placeholder="minimal_roi"13"" {...register("minimal_roi"13"", {, pattern: /0.044/i})} />
      <input type="number" placeholder="minimal_roi"51"" {...register("minimal_roi"51"", {})} />
      <input type="number" placeholder="minimal_roi"170"" {...register("minimal_roi"170"", {})} />
      <input type="number" placeholder="stoploss" {...register("stoploss", {, pattern: /-0.271/i})} />

      <input {...register("trailing_stop", { required: true })} type="radio" value="True" />
      <input {...register("trailing_stop", { required: true })} type="radio" value="False" />
      <input type="number" placeholder="trailing_stop_positive" {...register("trailing_stop_positive", {required: true, pattern: /0.011/i})} />
      <input type="number" placeholder="trailing_stop_positive_offset" {...register("trailing_stop_positive_offset", {required: true, pattern: /0.054/i})} />

      <input {...register("trailing_only_offset_is_reached")} type="radio" value="True" />
      <input {...register("trailing_only_offset_is_reached")} type="radio" value="False" />
      <input type="time" placeholder="timeframe" {...register("timeframe", {required: true, max: 15, min: 1, pattern: /5/i})} />

      <input type="submit" />
    </form>
  );
}